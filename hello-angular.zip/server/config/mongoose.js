var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/1955_api');

module.exports = mongoose;